{
	"sw":[
	{"no":"1","q":"This is Ronald. He ... of the company","a":[{"t":"is the chief"},{"t":"'s the boss"},{"t":"am the chef"},{"t":"manages"}],"r":"2"},
	{"no":"2","q":"We’re having a meeting to discuss the new project ... 10.30.","a":[{"t":"on"},{"t":"to"},{"t":"at"},{"t":"in"}],"r":"1"},
	{"no":"3","q":"How many ... she see every week?","a":[{"t":"customers does"},{"t":"appointments sees"},{"t":"directions makes"},{"t":"people meets"}],"r":"1"},
	{"no":"4","q":"I would like to speak to John, but I can’t ...","a":[{"t":"get off"},{"t":"get to"},{"t":"get in"},{"t":"get through"}],"r":"4"},
	{"no":"5","q":"The company ... in computers.","a":[{"t":"has planned a large investment"},{"t":"planned a large investigation"},{"t":"has a large invitation"},{"t":"a large involvement"}],"r":"1"},
	{"no":"6","q":"JBO ... by OBJ, yesterday.","a":[{"t":"were took over"},{"t":"has been taken over"},{"t":"was taken over"},{"t":"taken over"}],"r":"3"},
	{"no":"7","q":"The HR department is ... for recruitment.","a":[{"t":"responsibly"},{"t":"responsibility"},{"t":"responsible"},{"t":"response"}],"r":"3"},
	{"no":"8","q":"The ... study has been carried out three times, so far.","a":[{"t":"feasibility"},{"t":"feasible"},{"t":"feasibly"},{"t":"feast"}],"r":"1"},
	{"no":"9","q":"If the Board of Directors ... their approval, there will be a merger with Smiths.","a":[{"t":"would give"},{"t":"will give"},{"t":"gives"},{"t":"gave"}],"r":"3"},
	{"no":"10","q":"Since the merger with Smiths, the ... of the employees is very low.","a":[{"t":"morality"},{"t":"mural"},{"t":"moral"},{"t":"morals"}],"r":"3"},
	{"no":"11","q":"If the state didn’t open up the market, we ... a monopoly.","a":[{"t":"had"},{"t":"had had"},{"t":"would have"},{"t":"would had"}],"r":"3"},	
	{"no":"12","q":"The Finance Manager ... reduce the overheads, but oil costs stopped him.","a":[{"t":"wanted"},{"t":"was going to"},{"t":"is going to"},{"t":"will"}],"r":"2"},	
	{"no":"13","q":"I ... the job, if the perks hadn’t been so great.","a":[{"t":"wouldn’t had taken"},{"t":"wouldn’t have took"},{"t":"wouldn’t have taken"},{"t":"wouldn’t had took"}],"r":"3"},	
	{"no":"14","q":"This month’s import quota is really difficult to ...","a":[{"t":"figure out"},{"t":"figure up"},{"t":"figure in"},{"t":"figure to"}],"r":"1"},	
	{"no":"15","q":"By this time tomorrow, the team leader ... on the project budget for 24 hours.","a":[{"t":"will have working"},{"t":"will work"},{"t":"will have been working"},{"t":"will have been worked"}],"r":"3"},	
	{"no":"16","q":"No sooner had I finished the resource allocation for the project, than the whole thing ...","a":[{"t":"had been cancelled"},{"t":"was cancel"},{"t":"has been cancelled"},{"t":"was cancelled"}],"r":"4"},	
	{"no":"17","q":"The Director of Finance remembers ... the report for the fiscal year 2004/2005, but is not sure of the date.","a":[{"t":"to print"},{"t":"to printing"},{"t":"printing"},{"t":"print"}],"r":"3"},	
	{"no":"18","q":"Even though the President made the comments ..., it still appeared as a headline in work Times.","a":[{"t":"off the beat"},{"t":"off the cuff"},{"t":"off the scale"},{"t":"off the record"}],"r":"4"},	
	{"no":"19","q":"Analysts ... investing short term in the emerging markets, to make a quick profit.","a":[{"t":"have recommended"},{"t":"recommended to"},{"t":"have recommended to"},{"t":"recommends"}],"r":"1"},	
	{"no":"20","q":"The corporate headhunters ... Sharon, because she spoke 5 languages.","a":[{"t":"went after"},{"t":"went before"},{"t":"went for"},{"t":"went off"}],"r":"1"}
	]
	
	
	,"sj":[
	{"no":"1","q":"You are at an important dinner party and you are introduced to the CEO of WSI. What would you say?","a":[{"t":"Hi!"},{"t":"How do you do?"},{"t":"Hey there!"}],"r":"2"},
	{"no":"2","q":"You introduce your husband/wife to the CEO.","a":[{"t":"May I introduce my..."},{"t":"Say hi to..."},{"t":"My husband/wife!"}],"r":"1"},
	{"no":"3","q":"You want to point out that you had already been introduced to the CEO at another function.","a":[{"t":"I believe we met at the AGM last year."},{"t":"Yeah!! We met at that restaurant - what’s it’s name - you know the one with the singing cook!"},{"t":"Eh?? I know you?! How’s it going?"}],"r":"1"},
	{"no":"4","q":"You bump into your best friend at the buffet.","a":[{"t":"How do you do?"},{"t":"How pleasant to meet you."},{"t":"Hi!"}],"r":"3"},
	{"no":"5","q":"You arrive late to a meeting","a":[{"t":"The damn train was late."},{"t":"I’m afraid the train was late."},{"t":"Yipeee! I made it!"}],"r":"2"},
	{"no":"6","q":"You meet your boss at the coffee machine.","a":[{"t":"It’s a very great honour to meet you."},{"t":"What the hell are you doing here"},{"t":"Good morning, Mr. Peters."}],"r":"3"},
	{"no":"7","q":"You want to end an email to a colleague.","a":[{"t":"Regards,"},{"t":"Bye bye!"},{"t":"Answer me!!!"}],"r":"1"},
	{"no":"8","q":"You leave a message for your supervisor.","a":[{"t":"You leave a message for your supervisor."},{"t":"I would like to discuss the new figures. I am available all day at extension 123."},{"t":"Why not return my call when you get back from your 3 hour lunch break?"}],"r":"2"},
	{"no":"9","q":"A client comes to your office.","a":[{"t":"Sit!"},{"t":"There’s a chair."},{"t":"Please take a seat"}],"r":"3"},
	{"no":"10","q":"You want to start the meeting.","a":[{"t":"I suggest we start the meeting."},{"t":"Start!"},{"t":"Talk now!"}],"r":"1"}
	]
	
	
	,"sh":[
	{"no":"1","q":"What's your name?","a":[{"t":"John is."},{"t":"My name's John."},{"t":"My name John."},{"t":"I John."}],"r":"2"},
	{"no":"2","q":"... are you from? - I'm from France.","a":[{"t":"When"},{"t":"What"},{"t":"Where"},{"t":"Who"}],"r":"3"},
	{"no":"3","q":"How old are you? - I ... (16).","a":[{"t":"have sixteen"},{"t":"am sixteen"},{"t":"have sixty"},{"t":"am sixty"}],"r":"2"},
	{"no":"4","q":"There isn't ... money in the bank.","a":[{"t":"any"},{"t":"none"},{"t":"no"},{"t":"some"}],"r":"1"},
	{"no":"5","q":"Mrs Wilson usually ... to work.","a":[{"t":"drive"},{"t":"does drive"},{"t":"drives"},{"t":"driving"}],"r":"3"},
	{"no":"6","q":"I can see a big black cloud; I think it ... rain.","a":[{"t":"is going to"},{"t":"is to"},{"t":"will be"},{"t":"is"}],"r":"1"},
	{"no":"7","q":"He ... tennis since 1995.","a":[{"t":"hasn't played"},{"t":"wouldn't play"},{"t":"doesn't play"},{"t":"didn't play"}],"r":"1"},
	{"no":"8","q":"You don't need that coat in here; why don't you ...?","a":[{"t":"take off"},{"t":"take off it"},{"t":"off take it"},{"t":"take it off"}],"r":"4"},
	{"no":"9","q":"What do you want ... with all these books?","a":[{"t":"I'll do"},{"t":"me to do"},{"t":"me do"},{"t":"I do"}],"r":"2"},
	{"no":"10","q":"Last year I ... in Greece.","a":[{"t":"have been"},{"t":"was"},{"t":"were"},{"t":"did"}],"r":"2"},
	{"no":"11","q":"If ... enough money, I'd definitely get a new car.","a":[{"t":"I'll have"},{"t":"I'd had"},{"t":"I had"},{"t":"I'd have"}],"r":"3"},
	{"no":"12","q":"Sorry you didn't find me at home. ... out to do some shopping.","a":[{"t":"I've been going"},{"t":"I'll be going"},{"t":"I've gone"},{"t":"I'd gone"}],"r":"4"},
	{"no":"13","q":"The worst holiday ... was when we went camping.","a":[{"t":"I ever made"},{"t":"I've ever been to"},{"t":"I've ever had"},{"t":"I had ever"}],"r":"3"},
	{"no":"14","q":"How long ... in New York, then?","a":[{"t":"have you been lived"},{"t":"have you been living"},{"t":"do you live"},{"t":"are you living"}],"r":"2"},
	{"no":"15","q":"With this lovely weather there ... to be millions of people on the beach.","a":[{"t":"will certain"},{"t":"are certainly"},{"t":"are certain"},{"t":"are"}],"r":"3"},
	{"no":"16","q":"Are you sure we've never met? You ... someone I used to know.","a":[{"t":"remind me of"},{"t":"remember to me"},{"t":"remember me"},{"t":"remind me"}],"r":"1"},
	{"no":"17","q":"I know what that word means! I looked ... in my dictionary.","a":[{"t":"it up"},{"t":"to it"},{"t":"down"},{"t":"for it"}],"r":"1"},
	{"no":"18","q":"No sooner had I opened my front door ... that something was wrong","a":[{"t":"had I realized"},{"t":"did I realize"},{"t":"than I realized"},{"t":"and I realized"}],"r":"3"},
	{"no":"19","q":"This kind of music is very popular ... young people at the moment.","a":[{"t":"by"},{"t":"for"},{"t":"between"},{"t":"among"}],"r":"4"},
	{"no":"20","q":"If you ... you knew the General Manager you'd never have gotten that job, you know.","a":[{"t":"wouldn't say"},{"t":"hadn't said"},{"t":"wouldn't have said"},{"t":"didn't say"}],"r":"2"}
	]
}